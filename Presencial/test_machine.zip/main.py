from fastapi import FastAPI, Response, Form, Request
from pydantic import BaseModel
import requests
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from typing import List
import time
from prometheus_client import Counter, Summary, generate_latest, CONTENT_TYPE_LATEST
from fastapi.middleware.cors import CORSMiddleware
#HTML
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
#Uvicorn
import uvicorn

nltk.download("punkt")
nltk.download("stopwords")
nltk.download("punkt_tab")

app = FastAPI()
app.add_middleware(
CORSMiddleware,
allow_origins=["*"],
allow_credentials=True,
allow_methods=["*"],
allow_headers=["*"],
)

fluxos = {
    "Teste": ["nadar", "Nadar", "correr", "Correr"],
}

OLLAMA_URL = "http://localhost:11434/api/generate"

PREDICTION_TIME = Summary("inference_duration_seconds", "Duração da inferência")
PREDICTION_INFERENCE = Counter("inferences_total", "Número total de inferências")

templates = Jinja2Templates(directory="templates")

class Pergunta(BaseModel):
    pergunta: str

def extrair_palavras_chave(texto: str) -> List[str]:
    """Extrai palavras-chave da pergunta"""
    stop_words = set(stopwords.words("portuguese"))
    tokens = word_tokenize(texto.lower())  # Tokeniza e converte em minúsculas
    palavras_chave = [t for t in tokens if t.isalnum() and t not in stop_words]
    return palavras_chave

def determinar_fluxo(palavras_chave: List[str]) -> str:
    """Identifica o fluxo de trabalho baseado nas palavras-chave"""
    for fluxo, palavras in fluxos.items():
        # Verifica se alguma palavra-chave do fluxo aparece nas palavras extraídas
        if any(palavra in palavras_chave for palavra in palavras):
            return f"{fluxo.capitalize()}"
    return "Nenhum fluxo específico identificado."

def obter_resposta_llama(pergunta: str) -> str:
    """Obtém a resposta do modelo LLaMA"""
    payload = {
        "model": "qwen3:1.7b",
        "prompt": pergunta,
        "stream": False
    }
    resposta = requests.post(OLLAMA_URL, json=payload)
    return resposta.json().get("response", "Erro ao obter resposta")

#@app.get("/")
#def home():
#    return {"message": "API llama funcionando!"}

@app.get("/", response_class=HTMLResponse)
async def get_home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/metrics")
def get_metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.post("/pergunta/")
async def fazer_pergunta(pergunta: Pergunta):
    """Processa a pergunta, envia ao LLaMA e retorna a resposta"""
    palavras_chave = extrair_palavras_chave(pergunta.pergunta)
    
    PREDICTION_INFERENCE.inc()
    fluxo = determinar_fluxo(palavras_chave)
    
    # Obter resposta do LLaMA
    start_time = time.time()
    resposta_llama = obter_resposta_llama(pergunta.pergunta)
    duration = time.time() - start_time
    PREDICTION_TIME.observe(duration)
    return {"fluxo": fluxo, "Duração": duration, "resposta": resposta_llama}

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
